from repokid.cli.repokid_cli import Filter

class AutomationFilter(Filter):
    def apply(self, input_list):
        auto_roles = []
        services = ['cloudformation', 'application-autoscaling']
        for role in input_list:
            service_role = str(role.assume_role_policy_document).lower()
            if any (s in service_role for s in services):
                auto_roles.append(role)
        return list(auto_roles)
