from repokid.cli.repokid_cli import Filter

class SecurityFilter(Filter):
    def apply(self, input_list):
        security_roles = []
        services = ['inspector', 'guardduty', 'trustedadvisor', 'config']
        for role in input_list:
            service_role = str(role.assume_role_policy_document).lower()
            if any (s in service_role for s in services):
                security_roles.append(role)
        return list(security_roles)
