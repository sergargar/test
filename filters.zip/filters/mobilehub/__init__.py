from repokid import LOGGER
from repokid.cli.repokid_cli import Filter

class MobileHubFilter(Filter):
    def apply(self, input_list):
        mh_roles = []
        services = ['mobilehub', 'cognito-identity']
        frontpre = ['512704128816']
        for role in input_list:
            mh_role = str(role.assume_role_policy_document).lower()
            arn = str(role.arn)
            if any (a in arn for a in frontpre):
                if any (s in mh_role for s in services):
                    mh_roles.append(role)
        return list(mh_roles)
