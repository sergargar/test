from repokid import LOGGER
from repokid.cli.repokid_cli import Filter
import re

class BastionFilter(Filter):
    def apply(self, input_list):
        bastion_roles = []
        services = ['ec2']
        for role in input_list:
            b_role = str(role.assume_role_policy_document).lower()
            rolename = str(role.role_name)
            if any (s in b_role for s in services):
                if re.match(r"Bastion-BastionRole[-a-zA-Z0-9]{1,16}", rolename):
                    bastion_roles.append(role)
        return list(bastion_roles)
