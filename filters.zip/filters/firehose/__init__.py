from repokid.cli.repokid_cli import Filter


class FirehoseFilter(Filter):
    def apply(self, input_list):
        firehose_roles = []
        services = ['firehose', 'events']
        for role in input_list:
            service_role = str(role.assume_role_policy_document).lower()
            if any (s in service_role for s in services):
                firehose_roles.append(role)
        return list(firehose_roles)
