from repokid.cli.repokid_cli import Filter


class ApiGatewayFilter(Filter):
    def apply(self, input_list):
        apigateway_roles = []

        for role in input_list:
            if "apigateway" in str(role.assume_role_policy_document).lower():
                apigateway_roles.append(role)
        return list(apigateway_roles)
