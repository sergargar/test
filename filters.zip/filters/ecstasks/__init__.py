from repokid.cli.repokid_cli import Filter


class MicroservicesFilter(Filter):
    def apply(self, input_list):
        ecstasks_roles = []

        for role in input_list:
            if "ecs-tasks" in str(role.assume_role_policy_document).lower():
                ecstasks_roles.append(role)
        return list(ecstasks_roles)
