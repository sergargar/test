from repokid.cli.repokid_cli import Filter


class SrvcLinkedRoleFilter(Filter):
    def apply(self, input_list):
        srvc_roles = []

        for role in input_list:
            if "aws-service-role" in str(role.arn).lower():
                srvc_roles.append(role)
        return list(srvc_roles)
